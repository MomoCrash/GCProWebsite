<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../css/mainstyle.css" rel="stylesheet" type="text/css"/>
</head>
<body class="fond_page_news">
  <nav class="navbar_news" id="navbar">
      <div class="nav-img">
        <a href="#"><img src="../ressources/logo_black.svg" alt="logo home"></a>
      </div>
      <div class="nav-links">
        <ul>
          <li><a href="#">NEWS</a></li>
          <li><a href="#" class="nav-border">NOS EXPERIENCES</a></li>
          <li><a href="#" class="nav-border">A PROPOS DE NOUS</a></li>
          <li><a href="#" class="nav-border">NOS EQUIPEMENTS</a></li>
          <li><a href="#" class="nav-border"><b>CONNEXION</b></a></li>
        </ul>
      </div>
      <img src="../ressources/bouton_menu_by_moi.png" alt="menu_bouton" class="menu_bouton" id="menu_bouton">
  </nav>
  <header></header>
  <img width="100%"  src="../ressources/EN TÊTE.png">

  <!-- DERNIERE PARTIE -->
  <div class="second_part">
    <div class="pc"><img src="../ressources/fond.webp"></div>
    <div class="mobile"><img src="../ressources/fond.webp"></div>
  </div>



</body>

<!-- PAS TOUCHE -->

<footer>
  <div class="footer-nav">
      <a href="#"><span>Nous contacter</span></a>
      <a href="#"><span>Réservation</span></a>
      <a href="#"><span>FAQ</span></a>
  </div>
  <div class="copyright">
      © THE SENSE, SAS. Tous droits réservés
  </div>
  <div class="moda">
      <a href="#"><span>Modalités</span></a>
      <span> | </span>
      <a href="#"><span>Politique de confidentialité </span></a>
      <div class="contact">
        <span> | </span>
        <a href="#"><span>Contact</span></a>
      </div>
      
  </div>
  <div class="social-icons">
      <!-- Replace # with actual links to your social media profiles -->
      <a href="#"><img src="../ressources/Youtube.png" alt="Youtube"></a>
      <a href="#"><img src="../ressources/Instagram.png" alt="Instagram"></a>
      <a href="#"><img src="../ressources/Twitter.png" alt="Twitter"></a>
      <a href="#"><img src="../ressources/Facebook.png" alt="Facebook"></a>
  </div>
</footer>

<!-- POP UP VIDEO -->

<a href="#_" class="lightbox" id="img1">
  <div id="videoModal" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="videoModalLabel" aria-hidden="false" style="display: block;">
    <div class="modal-header"></div>
    <div class="modal-body"><iframe width="870" height="489" src="https://www.youtube.com/embed/9Qzm66JX-RA" frameborder="0" allowfullscreen=""></iframe></div>
    <div class="modal-footer"></div>
  </div>



  <script>

    const menubtns = document.querySelector(".menu_bouton")
    const navLinks = document.querySelector(".nav-links")
    const navbar = document.getElementById("navbar")
    var isOpen = true
    

    menubtns.addEventListener('click',()=>{
      navLinks.classList.toggle('mobile-menu');
      if(isOpen){
      navbar.style.backdropFilter = 'none';
      isOpen = false
      }else{
        navbar.style.backdropFilter = 'blur(10px)'
        isOpen = true
      }
    })

    function handleIntersection(entries, observer) {
      entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('footer-anim');
    // Optionnel: Désactivez l'observer si vous ne voulez l'animation qu'une seule fois
        observer.unobserve(entry.target);
        }
      });
    }

    // Création de l'observer avec la fonction et les options
    const observer = new IntersectionObserver(handleIntersection, {
    threshold: 0.1 // Déclenche l'animation lorsque 10% du footer est visible
    });

  // Cible le footer pour l'observer
  const footer = document.querySelector('footer');
  observer.observe(footer);


  </script>

</html>